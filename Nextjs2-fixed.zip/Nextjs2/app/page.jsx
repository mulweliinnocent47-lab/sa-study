'use client'

import "./Home.css"
import Link from "next/link"
import Button from "@/components/button.jsx"
import Card from "@/components/card.jsx"
import Footer from "@/components/footer.jsx"
import {
  IconBook,
  IconFileText,
  IconPencil,
  IconFacebook,
  IconX,
  IconInstagram,
  IconFlame,
} from "@/components/icons.jsx"

export default function Home() {
  const links = [
    { icon: <IconFacebook size={18} />, label: "Facebook" },
    { icon: <IconX size={18} />, label: "X" },
    { icon: <IconInstagram size={18} />, label: "Instagram" },
  ]
  const safety = ["privacy", "terms", "conditions"]

  return (
    <main>
      <section className="hero">
        <div className="container">
          <span className="hero-eyebrow">
            <IconFlame size={14} /> Built for SA students
          </span>
          <h1>Past papers, notes and AI practice — all in one place</h1>
          <p>
            Everything is organised by grade, province and subject, so you spend less
            time searching and more time studying.
          </p>
          <div className="hero-actions">
            <Link href="/sign-up"><Button info="Get started free" /></Link>
            <Link href="/log-in"><Button info="Log in" variant="outline" /></Link>
          </div>
        </div>
      </section>

      <section className="features">
        <div className="container">
          <h2>Everything you need to pass</h2>
          <p>One dashboard for papers, notes and practice.</p>
          <div className="card-grid card-grid--3">
            <Card
              large
              value={
                <>
                  <div className="feature-icon"><IconFileText size={22} /></div>
                  <h3 className="feature-card">Past Papers</h3>
                  <p className="feature-card">2018 – 2026, organised by subject and grade.</p>
                </>
              }
            />
            <Card
              large
              value={
                <>
                  <div className="feature-icon"><IconBook size={22} /></div>
                  <h3 className="feature-card">Notes</h3>
                  <p className="feature-card">Clear, exam-focused summaries for every subject.</p>
                </>
              }
            />
            <Card
              large
              value={
                <>
                  <div className="feature-icon"><IconPencil size={22} /></div>
                  <h3 className="feature-card">Practice</h3>
                  <p className="feature-card">Brainstorm and drill questions with ProAI.</p>
                </>
              }
              />
           <Card
              large
              value={
                <>
                  <div className="feature-icon"><IconBook size={22} /></div>
                  <h3 className="feature-card">Textbooks</h3>
                  <p className="feature-card">Clear, focus textbooks every subject.</p>
                </>
              }
            />
            
          </div>
        </div>
      </section>

      <Footer
        link={
          <div style={{ display: "flex", gap: 10 }} className="footer-social">
            {links.map((l) => (
              <a key={l.label} href="#" aria-label={l.label}>{l.icon}</a>
            ))}
          </div>
        }
        info={
          <div className="footer-legal">
            {safety.map((s) => (
              <a key={s} href="#">{s}</a>
            ))}
          </div>
        }
      />
    </main>
  )
}
