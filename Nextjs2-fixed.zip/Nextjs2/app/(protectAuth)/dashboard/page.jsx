"use client"
import Link from "next/link"
import Navbar from "@/components/navbar.jsx"
import Input from "@/components/input.jsx"
import Card from "@/components/card.jsx"
import Stars from "@/components/stars.jsx"
import Button from "@/components/button.jsx"
import Footer from "@/components/footer.jsx"
import "./dashboard.css"
import {
  IconCheck,
  IconFileText,
  IconBook,
  IconPencil,
  IconFacebook,
  IconX,
  IconInstagram,
} from "@/components/icons.jsx"

export default function Dashboard() {
  const nav = [
    { label: "Pricing", href: "/dashboard#pricing" },
    { label: "Notes", href: "/dashboard#notes" },
    { label: "Past Paper", href: "/dashboard#papers" },
    { label: "Profile", href: "/dashboard/profile" },
    { label: "settings", href: "/dashboard/settings" },
  ]
  const handleNav = nav.map((n) => (
    <li key={n.label}><Link href={n.href}>{n.label}</Link></li>
  ))

  const freeMember = [
    "5 downloads per month",
    "History + Maths + English only",
    "Notes and past papers older than 2 years",
    "Banner ads on site",
    "Basic search",
    "Email support within 48 hours",
  ]
  const handleFreeMember = freeMember.map((e) => (
    <li key={e}><IconCheck size={16} /> {e}</li>
  ))

  const links = [
    { icon: <IconFacebook size={18} />, label: "Facebook" },
    { icon: <IconX size={18} />, label: "X" },
    { icon: <IconInstagram size={18} />, label: "Instagram" },
  ]
  const handleLinks = links.map((l) => (
    <a key={l.label} href="#" aria-label={l.label}>{l.icon}</a>
  ))

  const safety = ["Privacy", "Terms", "Conditions", "Banned"]
  const handleSafety = safety.map((e) => <a key={e} href="#">{e}</a>)

  return (
    <>
      <header className="dash-header">
        <Navbar brand="SA Student" info={handleNav} />
        <div className="container">
          <h1>SA Student</h1>
          <p>Your dashboard for papers, notes and practice</p>
        </div>
      </header>

      <div className="container dash-search">
        <Input id="search" type="text" value="Search for fast navigation" showIcon />
      </div>

      <section className="dash-section container" id="pricing">
        <div className="card-grid card-grid--3">
          <Card
            large
            value={
              <div className="plan-card">
                <span className="badge">Free member</span>
                <h3>Do justice for your education</h3>
                <p className="tagline">Get them in the door — no credit card needed.</p>
              </div>
            }
            data={<ul className="member-list">{handleFreeMember}</ul>}
            button={<Button info="Go Pro Plan" />}
          />

          <Card
            large
            value={
              <div className="plan-card">
                <div className="resource-icon" style={{ margin: "0 auto" }}><IconFileText size={22} /></div>
                <h3 className="resource-card">Past Papers</h3>
                <p className="resource-card">2018 – 2026</p>
              </div>
            }
            button={<Button info="Continue" />}
          />

          <Card
            large
            value={
              <div className="plan-card">
                <div className="resource-icon" style={{ margin: "0 auto" }}><IconBook size={22} /></div>
                <h3 className="resource-card">Notes</h3>
                <p className="resource-card">2018 – 2026</p>
              </div>
            }
            button={<Button info="Continue" />}
          />
        </div>

        <div style={{ marginTop: 16 }}>
          <Card
            large
            value={
              <div className="plan-card">
                <div className="resource-icon" style={{ margin: "0 auto" }}><IconPencil size={22} /></div>
                <h3 className="resource-card">Practice</h3>
                <p className="resource-card">Brainstorm ideas with ProAI</p>
              </div>
            }
            button={<Link href="/practice"><Button info="Continue" /></Link>}
          />
        </div>
      </section>

      <section className="dash-section container">
        <div className="cta-band">
          <Stars />
          <h3>Your future awaits you</h3>
          <p>Join thousands of SA students getting notes, past papers and AI-powered practice in one place.</p>
          <Link href="/dashboard/settings"><Button info="Go Pro Plan" full={false} /></Link>
        </div>
      </section>

      <Footer
        link={<div className="footer-social" style={{ gap: 10 }}>{handleLinks}</div>}
        info={<div className="footer-legal" style={{ gap: 14, flexWrap: "wrap" }}>{handleSafety}</div>}
      />
    </>
  )
}
