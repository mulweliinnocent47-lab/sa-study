'use client'
import "./settings.css"
import Button from "@/components/button.jsx"
import Navbar from "@/components/navbar.jsx"
import Card from "@/components/card.jsx"
import Theme from "@/components/theme.jsx"
import Input from "@/components/input.jsx"
import { useState } from "react"
import Link from "next/link"
import { createClient } from "@/utils/supabase/client"
import { useRouter } from "next/navigation"

export default function Settings() {
  const router = useRouter()

  const nav = ["notifications", "history", "theme", "billing", "about", "devices"]
  const [activeTab, setActiveTab] = useState("notifications")

  const handleNav = nav.map((e) => {
    return (
      <li
        className={`navbar-settings${activeTab === e ? " active" : ""}`}
        onClick={() => setActiveTab(e)}
        key={e}
      >
        {e}
      </li>
    )
  })

  const handleLogout = async () => {
    const supabase = createClient()
    const { error } = await supabase.auth.signOut()

    if (error) {
      console.error("Logout error:", error)
      return
    }

    router.push("/")
  }

  return (
    <>
      <Navbar brand={<Link href="/dashboard">{activeTab}</Link>} info={handleNav} />
      <div className="container settings-page">
        {activeTab === "notifications" && (
          <section id="notifications" className="card-grid card-grid--2">
            <Card value={
              <div className="permission">
                <p className="permission-title">New Notes/Past Paper Alert</p>
                <Button info="Allow" variant="outline" full={false} />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Exam Reminder</p>
                <Input type="date" id="date" pro="Set Date" value="set exam date" />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Download Complete</p>
                <Button info="Allow" variant="outline" full={false} />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Email Notification</p>
                <Input type="email" id="email" pro="Email optional" value="enter your email" />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Whatsapp Notification</p>
                <Input type="number" id="number" pro="Whatsapp Number optional" value="enter your Whatsapp Number" />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Quiet Hours</p>
                <div className="input-row">
                  <Input type="time" id="quiet-start" pro="From" value="10:00 PM" />
                  <Input type="time" id="quiet-end" pro="To" value="6:00 AM" />
                </div>
              </div>
            } />
            <div className="settings-actions">
              <Button info="Save" full={false} />
            </div>
          </section>
        )}

        {activeTab === "history" && (
          <section id="history" className="card-grid card-grid--2">
            <Card value={
              <div className="permission">
                <p className="permission-title">Download History</p>
                <p className="permission-line">Grade 12 History P1 2023 — 2 days ago</p>
                <p className="permission-line">Grade 11 Maths Notes — 1 week ago</p>
                <Button info="Clear History" variant="outline" full={false} />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Search History</p>
                <p className="permission-line">history grade 12, maths notes, past papers</p>
                <Button info="Clear Searches" variant="outline" full={false} />
              </div>
            } />
            <div className="settings-actions">
              <Button info="Export History" full={false} />
            </div>
          </section>
        )}

        {activeTab === "theme" && (
          <section id="theme" className="card-grid card-grid--2">
            <Card value={
              <div className="permission">
                <p className="permission-title">Choose Theme</p>
                <div className="theme-flex">
                  <Theme color="blue" value="lightblue" />
                  <Theme color="black" value="black" />
                  <Theme color="pink" value="pink" />
                  <Theme color="purple" value="purple" />
                  <Theme color="yellow" value="yellow" />
                </div>
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Font Size</p>
                <div className="button-row">
                  <Button info="Small" variant="outline" full={false} />
                  <Button info="Medium" full={false} />
                  <Button info="Large" variant="outline" full={false} />
                </div>
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Go Pro with insane themes</p>
                <Button info="Upgrade to Pro" full={false} />
              </div>
            } />
          </section>
        )}

        {activeTab === "billing" && (
          <section id="billing" className="card-grid card-grid--3">
            <Card value={
              <div className="permission">
                <p className="permission-title">Current Plan: FREE</p>
                <p className="permission-line">Access: Basic notes + 5 downloads/month</p>
                <Button info="Upgrade to Go" full={false} />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">GO PLAN — R49/month</p>
                <p className="permission-line">Unlimited downloads + No ads</p>
                <Button info="Upgrade" variant="outline" full={false} />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">PRO PLAN — R99/month</p>
                <p className="permission-line">Everything in Go + 4 Devices + Premium Themes</p>
                <Button info="Upgrade" full={false} />
              </div>
            } />
          </section>
        )}

        {activeTab === "about" && (
          <section id="about" className="card-grid card-grid--2">
            <Card value={
              <div className="permission">
                <p className="permission-title">SA Student Hub v1.0.0</p>
                <p className="permission-line">Made in 2026 by Mulweli Innocent for SA students</p>
                <p className="permission-line">Student notes, past papers, and exam help</p>
                <div className="button-row">
                  <Button info="Terms & Conditions" variant="outline" full={false} />
                  <Button info="Privacy Policy" variant="outline" full={false} />
                </div>
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Support Us</p>
                <p className="permission-line">Have questions or feedback? We'd love to hear from you.</p>
                <Button info="Contact Support" full={false} />
              </div>
            } />
          </section>
        )}

        {activeTab === "devices" && (
          <section id="devices" className="card-grid card-grid--2">
            <Card value={
              <div className="permission">
                <p className="permission-title">Current Device</p>
                <p className="permission-line">📱 Samsung Galaxy — Soweto, GP — Active Now</p>
                <Button variant="outline" info="This Device" full={false} />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Other Devices</p>
                <p className="permission-line">💻 Windows PC — Last active 3 days ago</p>
                <Button info="Sign Out" variant="outline" full={false} />
              </div>
            } />
            <Card value={
              <div className="permission">
                <p className="permission-title">Go Pro Plan to start linking devices</p>
                <p className="permission-line">Link up to 4 devices with one payment</p>
                <Button variant="outline" info="Upgrade to Pro" full={false} />
              </div>
            } />
            <div className="settings-actions">
              <Button info="Log Out" onClick={handleLogout} full={false} />
            </div>
          </section>
        )}
      </div>
    </>
  )
}
