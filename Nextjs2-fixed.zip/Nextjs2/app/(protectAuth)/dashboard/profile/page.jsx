"use client"

import Card from "@/components/card.jsx"
import Avatar from "@/components/avatar.jsx"
import Input from "@/components/input.jsx"
import Select from "@/components/select.jsx"
import Button from "@/components/button.jsx"
import Link from "next/link"
import "./profile.css"
import {useState,useEffect} from "react"
import { createClient } from "@/utils/supabase/client"
import { useRouter } from "next/navigation";

export default function Profile(){
    const [data, setData] = useState([])
   const grade = ["7", "8", "9", "10", "11", "12"]
   const age = ["4-10", "11-13", "14-16", "16-18", "19-25", "25+"]
   const province = ["Gauteng", "Limpopo", "Mpumalanga", "KwaZulu Natal", "Eastern Cape", "Western Cape", "North West", "Free State", "Northern Cape"]
  const stream = ["Science", "Commerce", "General", "Physics", "Programming", "Other"]
  const goal = ["Distinction", "75%+", "Bachelor Pass", "Diploma Pass", "Higher Certificate Pass"]
  const aboutUs = ["Google", "TV", "AI", "YouTube", "TikTok", "Newspaper", "Someone", "Other"]
  const toOptions = (arr) => arr.map((v) => <option key={v} value={v}>{v}</option>)
  
    async function getData(){
       const supabase = createClient()
       const { data, error } = await supabase.from("profile_info").select("*")
       if(error){
         console.error(error)
         return
        }
        setData(data ?? [])
   }
  useEffect(() =>{
   getData()
  },[])
 
  return(
   <>
     <Link href="/dashboard"><h1>SA Student</h1></Link>
     <div className="profile-card">
      <div className="avatar">MG</div>
      {data.map((info) => (
       <p key={info.id} className="profile-name">
         Mr {info.name}
        </p>
      ))}
      <span className="profile-badge">Free Member</span>
      
      <div className="stats">
        <div className="stat-box">pdf/files opened
        <br/><b>12</b></div>
        <div className="stat-box">pdf/files downloaded<br/><b>8</b></div>
      </div>
    </div>
    <Input type="text" value="username" id="username" pro="Username" />
    <Input type="email" value="email" id="email" pro="Email" />
        <Select id="grade" pro="Grade" data={toOptions(grade)} />
        <Select id="province" pro="Province" data={toOptions(province)} />
        <Select id="stream" pro="Stream" data={toOptions(stream)} />
        <Select id="goal" pro="Goal" data={toOptions(goal)} />
        <Select id="age" pro="Age" data={toOptions(age)} />
        <Input type="text" value="school" id="school" pro="School Name Optional" />
    <Input type="password" value="password" id="password" pro="Password" />
    <Input type="password" value="Confirm password" id="Confirm" pro="Confirm Password" />
    
    <Button info="Save Changes"  /><br />
    <Button info="Delete Account" variant="outline" />
   </>
    )
}