"use client"

import "./set-profile.css"
import Input from "@/components/input.jsx"
import Select from "@/components/select.jsx"
import Button from "@/components/button.jsx"
import {useState} from "react"
import { createClient } from "@/utils/supabase/client"
import { useRouter } from "next/navigation";

export default function SetProfile() {
  const router = useRouter()
  const [info, setInfo] = useState({
    name:"", grade:"", province:"", stream:"", goal:"", school:"", aboutUs:"", age:""
  })
  
  function handle(e){
    setInfo((prev) => ({...prev,[e.target.name]:e.target.value}))
  }
 async function handleSubmit(e){
    e.preventDefault()
    if(!info){
      alert("add some values")
      return
    }
    const supabase = createClient()
    const {error} = await supabase.from("profile_info").insert(info).single()
    if(error){
      console.error(error)
      return
    }
    router.push("/dashboard")
  }
  const grade = ["7", "8", "9", "10", "11", "12"]
  const province = ["Gauteng", "Limpopo", "Mpumalanga", "KwaZulu Natal", "Eastern Cape", "Western Cape", "North West", "Free State", "Northern Cape"]
  const stream = ["Science", "Commerce", "General", "Physics", "Programming", "Other"]
  const goal = ["Distinction", "75%+", "Bachelor Pass", "Diploma Pass", "Higher Certificate Pass"]
  const aboutUs = ["Google", "TV", "AI", "YouTube", "TikTok", "Newspaper", "Someone", "Other"]

  const toOptions = (arr) => arr.map((v) => <option key={v} value={v}>{v}</option>)

  return (
    <div className="profile-page">
      <header className="profile-header">
        <p>SA Student</p>
      </header>
     
      <main className="profile-form">
        <span className="helper">This helps us filter content to your choices.</span>
         <form onSubmit={handleSubmit} >
        <Input must={true} pro="Username" id="username" type="text" value="Your name" logic={handle}/>
        <Select id="grade" logic={handle} pro="Grade" data={toOptions(grade)} />
        <Select id="province" logic={handle} pro="Province" data={toOptions(province)} />
        <Select id="stream" logic={handle} pro="Stream" data={toOptions(stream)} />
        <Select id="goal" logic={handle} pro="Goal" data={toOptions(goal)} />
        <Input must={true} pro="School name" logic={handle} id="school" type="text" value="School name (optional)" />
        <Select id="aboutUs" logic={handle} pro="Where did you hear about us?" data={toOptions(aboutUs)} />
        <Button type="submit" info="Done" />
        </form>
      </main>
    </div>
  )
}
