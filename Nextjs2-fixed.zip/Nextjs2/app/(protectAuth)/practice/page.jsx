import "./practice.css"
import Card from "@/components/card.jsx"
import Button from "@/components/button.jsx"

export default function Practice() {
  const stat = (label, value) => (
    <>
      <p className="stat-value">{value}</p>
      <p className="stat-label">{label}</p>
    </>
  )

  const subjects = ["Mathematics", "Physical Sciences", "English", "Life Sciences"]

  const achievements = ["🥶", "🍻", "🚢", "😉", "🥰", "😃", "🧑‍🤝‍🧑", "👶", "😂", "🔴"]

  return (
    <div className="container">
      <header className="topbar">
        <h1>Welcome back, @BikoLearner23 🔥</h1>
        <p>Grade 12 · Gauteng · 12 day streak</p>
      </header>

      <section className="stats card-grid card-grid--3">
        <Card value={stat("Papers Completed", 17)} />
        <Card value={stat("Average Score", "65%")} />
        <Card value={stat("Points Earned", 1263)} />
      </section>

      <section className="subjects">
        <h2>My Subjects</h2>
        <div className="card-grid card-grid--2">
          {subjects.map((s) => (
            <Card
              key={s}
              value={<h3 className="subject-card">{s}</h3>}
              data={<p className="subject-card">Continue where you left off</p>}
              button={<Button info="Practice" />}
            />
          ))}
        </div>
      </section>

      <section className="achievements">
        <h2>Achievements Earned</h2>
        <Card value={<div className="achievement-grid">{achievements.map((a, i) => <span key={i}>{a}</span>)}</div>} />
      </section>
    </div>
  )
}
