import "./globals.css";

export const metadata = {
  title: "SA Student",
  description: "Past papers, notes and AI-powered practice for South African students.",
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
