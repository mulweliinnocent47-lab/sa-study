import "./card.css"

export default function Card({ value, data, button, large }) {
  return (
    <div className={`card${large ? " card--pad-lg" : ""}`}>
      {value}
      {data}
      {button}
    </div>
  )
}
