import "./avatar.css"

export default function Avatar({pro}){
  return(
    <div className="avatar">{pro}</div>
    )
}