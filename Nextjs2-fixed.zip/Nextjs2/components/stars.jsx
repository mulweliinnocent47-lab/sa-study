import "./stars.css"
import { IconStar } from "./icons.jsx"

export default function Stars() {
  return (
    <div className="stars" role="img" aria-label="5 out of 5 stars">
      {[1, 2, 3, 4, 5].map((e) => (
        <span className="star" key={e}>
          <IconStar size={32} />
        </span>
      ))}
    </div>
  )
}
