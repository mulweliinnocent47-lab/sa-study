import "./button.css"

export default function Button({ info, variant, type = "button", onClick, full = true }) {
  const classes = ["btn", variant === "outline" ? "btn--outline" : "", full ? "" : "btn--auto"]
    .filter(Boolean)
    .join(" ")
  return (
    <button type={type} className={classes} onClick={onClick}>
      {info}
    </button>
  )
}
