import "./select.css"
import { IconChevronDown } from "./icons.jsx"

export default function Select({logic, pro, id, data }) {
  return (
    <div className="field-select">
      {pro && <label htmlFor={id}>{pro}</label>}
      <div className="field-select-control">
        <select id={id} name={id} onChange={logic} defaultValue="">
          <option value="" disabled>{pro}</option>
          {data}
        </select>
        <IconChevronDown size={16} />
      </div>
    </div>
  )
}
