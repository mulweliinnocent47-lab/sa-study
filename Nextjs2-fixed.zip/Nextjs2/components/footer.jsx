import "./footer.css"

export default function Footer({ link, info }) {
  return (
    <footer className="site-footer">
      <div className="container site-footer-inner">
        {link}
        {info}
        <p className="footer-copy">© {new Date().getFullYear()} SA Student. All rights reserved.</p>
      </div>
    </footer>
  )
}
