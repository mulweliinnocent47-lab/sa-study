import "./card.css"

export default function Theme({color,value,data,button}){
  return(
     <div className={`card theme ${color}`}>
      {value}
      {data}
      {button}
    </div>
    )
}