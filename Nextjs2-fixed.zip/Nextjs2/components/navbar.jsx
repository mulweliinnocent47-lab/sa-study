'use client'
import { useState } from "react"
import "./navbar.css"
import { IconMenu, IconClose } from "./icons.jsx"

export default function Navbar({ brand, info }) {
  const [open, setOpen] = useState(false)
  return (
    <nav className="navbar">
      <div className="container navbar-inner">
        {brand && <span className="navbar-brand">{brand}</span>}
        <button
          className="navbar-toggle"
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          {open ? <IconClose size={22} /> : <IconMenu size={22} />}
        </button>
        <ul className={`navbar-links${open ? " open" : ""}`} onClick={() => setOpen(false)}>
          {info}
        </ul>
      </div>
    </nav>
  )
}
