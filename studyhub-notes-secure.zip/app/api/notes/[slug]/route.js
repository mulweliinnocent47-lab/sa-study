import { createClient } from "@/utils/supabase/server";
import { BUCKET, FOLDER } from "@/lib/notesServer";

export const dynamic = "force-dynamic";

export async function GET(request, { params }) {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return new Response("Unauthorized", { status: 401 });
  }

  const slug = params.slug;

  const { data: files, error: listError } = await supabase.storage
    .from(BUCKET)
    .list(FOLDER, { limit: 100 });

  if (listError) {
    console.error("Notes list error:", listError);
    return new Response("Could not load note", { status: 500 });
  }

  const file = (files ?? []).find(
    (item) => item?.name === slug && item.name.toLowerCase().endsWith(".txt")
  );

  if (!file) {
    return new Response("Note not found", { status: 404 });
  }

  const { data: blob, error: downloadError } = await supabase.storage
    .from(BUCKET)
    .download(`${FOLDER}/${file.name}`);

  if (downloadError || !blob) {
    console.error("Note download error:", downloadError);
    return new Response("Could not load note", { status: 500 });
  }

  const text = await blob.text();

  return new Response(text, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
