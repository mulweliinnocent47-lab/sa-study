# SA Study — Next.js JSX

Converted from the uploaded StudyHub SA project to Next.js App Router using JSX.

## Run

```bash
npm install
npm run dev
```

Routes:
- /
- /papers
- /notes
- /notes/[slug]
- /practice
- /settings
